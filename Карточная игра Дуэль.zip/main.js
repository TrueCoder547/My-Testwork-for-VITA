let Playercards = [0,1,2,3,4,5,6,7,8,9,10,11];
let Botcards = [0,1,2,3,4,5,6,7,8,9,10,11];
let pointsplayer = 0;
let pointsbot = 0;
let Banpoints = 0;
for(  let Mycard of Playercards){
    Mycard = Playercards[0];
while (Mycard < 12){
    let Botcard = Math.floor(Math.random() * Botcards.length);
    console.log(Botcard);
    console.log(Mycard);
    if( Mycard < Botcard){
        pointsbot =  pointsbot +Botcard;
        Banpoints = Botcard-Mycard;
        console.log('Компьютер получает штрафные очки',Banpoints);
    }
    if (Mycard > Botcard){
        pointsplayer = pointsplayer + Mycard;
        Banpoints = Botcard+Mycard;
        console.log('Вы получаете штрафные очки',Banpoints);
    }
    else  if ( Mycard == Botcard){
        console.log('У вас одинаковы карты, оба игрока получают 0 очков');
    }
    Mycard++;  
}
break;
}
if (pointsplayer > pointsbot){
    console.log('Компьютер победил!');
}
if(pointsplayer < pointsbot){
    console.log('Вы выиграли!');
}
else  if(pointsplayer == pointsbot){
    console.log('Ничья!');
}
console.log('Ваши очки',pointsplayer);
console.log('Очки компьютера',pointsbot);
