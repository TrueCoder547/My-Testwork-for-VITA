if (!localStorage.level) localStorage.level = 1
if (!localStorage.progressbarWidth) localStorage.progressbarWidth = 0

function randomNumber(min ,max){
    return Math.floor(Math.random() * (max-min) + min)
}

function setCards() {
    const firstNum = randomNumber(1,12)
    const secondNum = randomNumber(1,12)

    if (firstNum==secondNum){ 
        setCards()
        return
    }
    firstCard.innerText = firstNum
    secondCard.innerText = secondNum
}
firstCard.onclick = () => {
const firstNum = Number(firstCard.innerText)
const secondNum = Number(secondCard.innerText)
let progressbarWidth = Number(progressbar.style.width.replace('px','').replace('%',''))

if (firstNum > secondNum){ 
firstCard.classList.add('success')
progressbar.style.width = progressbarWidth + 10 +'%'
} else { 
    firstCard.classList.add('danger')
    if(progressbar.style.width.replace('px','').replace('%','') >=0 )
    progressbar.style.width = progressbarWidth - 10 +'%'
}

if(progressbar.style.width == '100%'){
progressbar.style.width ='0%'
localStorage.level++   
}
progressbarWidth = Number(progressbar.style.width.replace('px','').replace('%',''))
localStorage.progressbarWidth = progressbarWidth

glass.classList.add('active')
setTimeout(() =>{
    setCards()
    glass.classList.remove('active')
    firstCard.classList.remove('success')
    firstCard.classList.remove('danger')
},1500)
}


secondCard.onclick = () => {
    const firstNum = Number(firstCard.innerText)
    const secondNum = Number(secondCard.innerText)
    let progressbarWidth = Number(progressbar.style.width.replace('px', '').replace('%', ''))
    
    if (firstNum < secondNum) {
        progressbar.style.width = progressbarWidth + 10 +'%'
        secondCard.classList.add('success')
    } else {
        secondCard.classList.add('danger')
        if(progressbar.style.width.replace('px', '').replace('%', '') >=0 )
        progressbar.style.width = progressbarWidth - 10 +'%'
    }

    if(progressbar.style.width == '100%'){
    progressbar.style.width = '0%'
    localStorage.level++
    }

    progressbarWidth = Number(progressbar.style.width.replace('px', '').replace('%', ''))
    localStorage.progressbarWidth = progressbarWidth

    glass.classList.add('active')
    setTimeout(() =>{
        setCards()
        glass.classList.remove('active')
        secondCard.classList.remove('success')
        secondCard.classList.remove('danger')
    },1500) 
}
function setLevelSpan(){
    levelSpan.innerText = localStorage.level
}
function setProgressbar () {
    progressbar.style.width = localStorage.progressbarWidth + '%'
}
onkeydown = event => {
    if (event.key == ' '){
        const confirmReset = confirm("Вы действительно хотите сбросить прогресс?")
        if (confirmReset){
            localStorage.clear()
            location.reload()
        }
    }
}
setInterval(setLevelSpan, 1000)
setProgressbar()
setLevelSpan()
setCards() 